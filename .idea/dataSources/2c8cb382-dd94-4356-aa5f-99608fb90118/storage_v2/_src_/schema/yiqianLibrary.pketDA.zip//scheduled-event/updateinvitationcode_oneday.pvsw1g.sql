create definer = root@`%` event updateInvitationCode_OneDay
  on schedule
    every '1' DAY
      starts '2020-06-27 01:00:00'
  enable
do
  BEGIN
 
update invitationCodeList set oneDay=5;

END;

